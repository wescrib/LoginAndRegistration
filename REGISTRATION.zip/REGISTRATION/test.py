from flask import Flask, request, redirect, render_template, flash, session
from mysqlconnection import MySQLConnector
import re
import bcrypt

app = Flask(__name__)
mysql = MySQLConnector(app,'users_database')
app.secret_key="chamber of secrets"

EMAIL_REGEX=re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route('/')
def index():                        
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    errors=[]

    if len(request.form(['first_name'])) < 1:
        errors.append("First name is blank")
    if len(request.form(['last_name'])) < 1:
        errors.append("Last name is blank")
    if len(request.form(['password'])) < 1:
        errors.append("Password is blank")
    if len(request.form(['confirmPassword'])) < 1:
        errors.append("Confirm password is blank")
    elif request.form['confirmPassword'] != request.form['password']:
        errors.append("Passwords do not match")
    if len(request.form(['email'])) < 1:
        errors.append("Email is blank")
    elif not EMAIL_REGEX.match(request.form["email"]):
        errors.append("Invalid Email")

    for error in errors:
        flash(error)
    print request.form
    if errors ==[]:
        query = "INSERT INTO users(first_name, last_name,email,password,created_at, updated_at) VALUES (:first_name, :last_name, :email, :password,NOW(),NOW()"
        date = {
            'first_name': request.form('first_name')
        }





@app.route("/success")
def success():
    if "user_id" not in session:
        flash("You have to login first")
        return redirect('/')
    return render_template("success.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

app.run(debug=True)